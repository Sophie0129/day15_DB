package ex01.service;

public interface MemberService {
	public void memberView();
	public void modify();
}
