module db_conn {
	exports ex01;
	requires java.sql;
}